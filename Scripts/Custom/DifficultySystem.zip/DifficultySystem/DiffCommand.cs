using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using Server;
using Server.Mobiles;


// Enhanced commands with gump interface
namespace Server.Commands
{
    public partial class DifficultyCommands
    {
        // Add this to the existing DifficultyCommands class
        
        [Usage("DifficultyMenu")]
        [Aliases("DMenu")]
        [Description("Opens the difficulty selection menu.")]
        public static void DifficultyMenu_OnCommand(CommandEventArgs e)
        {
            e.Mobile.SendGump(new Server.Gumps.DifficultySelectionGump(e.Mobile));
        }
    }
}