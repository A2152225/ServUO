using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using Server;
using Server.Mobiles;

// Player Mobile extension for character-specific difficulty saving
namespace Server.Mobiles
{
    public partial class PlayerMobile
    {
        private int m_DifficultyLevel = 1;
        
        [CommandProperty(AccessLevel.GameMaster)]
        public int DifficultyLevel
        {
            get { return m_DifficultyLevel; }
            set 
            { 
                m_DifficultyLevel = Math.Max(1, Math.Min(12, value));
                Server.Systems.Difficulty.DifficultyTracker.SetPlayerDifficultyInternal(this, m_DifficultyLevel);
            }
        }

        // Add to existing Serialize method
        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);
            
            writer.Write((int)1); // Difficulty version
            writer.Write((int)m_DifficultyLevel);
        }

        // Add to existing Deserialize method  
        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);
            
            // Check if difficulty data exists
            if (reader.PeekInt() == 1) // Our version marker
            {
                int version = reader.ReadInt();
                m_DifficultyLevel = reader.ReadInt();
                
                // Restore difficulty setting
                Server.Systems.Difficulty.DifficultyTracker.SetPlayerDifficultyInternal(this, m_DifficultyLevel);
            }
        }

        // Override login to ensure difficulty is set
        public override void OnLogin()
        {
            base.OnLogin();
            
            // Ensure difficulty is properly set
            Server.Systems.Difficulty.DifficultyTracker.SetPlayerDifficultyInternal(this, m_DifficultyLevel);
            
            // Send welcome message about difficulty system
            Timer.DelayCall(TimeSpan.FromSeconds(2.0), () =>
            {
                if (NetState != null)
                {
                    SendMessage(38, $"Your difficulty level is set to {m_DifficultyLevel}. Use .SetDifficulty <1-12> to change it.");
                    if (m_DifficultyLevel == 1)
                    {
                        SendMessage(68, "Try increasing your difficulty for better rewards and a greater challenge!");
                    }
                }
            });
        }

        public override void OnLogout()
        {
            base.OnLogout();
            Server.Systems.Difficulty.DifficultyTracker.OnPlayerDisconnected(this);
        }
    }
}
