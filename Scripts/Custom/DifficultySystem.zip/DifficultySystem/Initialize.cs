using Server;
using Server.Commands;

namespace Server.Systems.Difficulty
{
    public class DifficultySystemInit
    {
        public static void Initialize()
        {
            DifficultyCommands.Initialize();
            
            // Optional: Load player difficulties from file
            // LoadPlayerDifficulties();
        }
        
        // Optional: Save/Load system for persistence
        public static void SavePlayerDifficulties()
        {
            // Implement save to file
        }
        
        public static void LoadPlayerDifficulties()
        {
            // Implement load from file
        }
    }
}