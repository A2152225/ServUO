#region Header
//   Vorspire    _,-'/-'/  TrapSweeperMode.cs
//   .      __,-; ,'( '/
//    \.    `-.__`-._`:_,-._       _ , . ``
//     `:-._,------' ` _,`--` -: `_ , ` ,' :
//        `---..__,,--'  (C) 2018  ` -'. -'
//        #  Vita-Nex [http://core.vita-nex.com]  #
//  {o)xxx|===============-   #   -===============|xxx(o}
//        #        The MIT License (MIT)          #
#endregion

namespace VitaNex.Modules.Games
{
	public enum TrapSweeperMode
	{
		Easy,
		Normal,
		Hard,
		Random
	}
}